
import React from 'react';
import { Settings, Wrench, ShoppingBag, Droplets, ShieldCheck, Clock, Zap, MapPin } from 'lucide-react';
import { BusinessInfo, Service } from './types';

export const BUSINESS_INFO: BusinessInfo = {
  name: "Chitech Tools and Equipment",
  owner: "Stanley Ugbala",
  location: "Lagos, Nigeria",
  phone: "09062217473",
  whatsapp: "2349062217473",
  facebook: "https://www.facebook.com/share/1A4PZCogkU/",
  email: "info@chitechtools.com",
  hours: "Mon - Sat: 8:00 AM - 6:00 PM"
};

export const SERVICES: Service[] = [
  {
    id: 'repair',
    title: 'Expert Repair',
    description: 'Comprehensive repair services for all makes and models of pallet jacks. We fix structural and mechanical issues quickly.',
    icon: <Wrench className="w-8 h-8 text-blue-600" />
  },
  {
    id: 'maintenance',
    title: 'Routine Maintenance',
    description: 'Preventive care to extend the life of your equipment. Includes lubrication, inspection, and tightening of all components.',
    icon: <Settings className="w-8 h-8 text-blue-600" />
  },
  {
    id: 'hydraulic',
    title: 'Hydraulic Servicing',
    description: 'Specialized hydraulic system bleeding, oil replacement, and seal repairs to ensure smooth lifting operations.',
    icon: <Droplets className="w-8 h-8 text-blue-600" />
  },
  {
    id: 'parts',
    title: 'Spare Parts',
    description: 'Genuine high-quality replacement parts including wheels, bearings, handles, and hydraulic pumps.',
    icon: <Zap className="w-8 h-8 text-blue-600" />
  },
  {
    id: 'sales',
    title: 'Equipment Sales',
    description: 'We sell brand new and refurbished pallet jacks suited for heavy-duty warehouse and industrial use.',
    icon: <ShoppingBag className="w-8 h-8 text-blue-600" />
  }
];

export const TRUST_BENEFITS = [
  {
    title: 'Fast Service',
    description: 'Minimizing your downtime with quick turnarounds.',
    icon: <Clock className="w-6 h-6 text-blue-600" />
  },
  {
    title: 'Affordable Pricing',
    description: 'Competitive rates for high-quality professional work.',
    icon: <ShieldCheck className="w-6 h-6 text-blue-600" />
  },
  {
    title: 'On-site Repairs',
    description: 'We come to your warehouse for convenience.',
    icon: <MapPin className="w-6 h-6 text-blue-600" />
  }
];
