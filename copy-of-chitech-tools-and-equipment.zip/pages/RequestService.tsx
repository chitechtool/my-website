
import React, { useState } from 'react';
import { Send, CheckCircle, Info, Loader2, AlertCircle, ChevronDown } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const COUNTRY_CODES = [
  { code: '+234', label: '🇳🇬 Nigeria', name: 'NG' },
  { code: '+233', label: '🇬🇭 Ghana', name: 'GH' },
  { code: '+229', label: '🇧🇯 Benin', name: 'BJ' },
  { code: '+237', label: '🇨🇲 Cameroon', name: 'CM' },
  { code: '+225', label: '🇨🇮 Ivory Coast', name: 'CI' },
  { code: '+1', label: '🇺🇸 USA/CAN', name: 'US' },
  { code: '+44', label: '🇬🇧 UK', name: 'GB' },
  { code: '+86', label: '🇨🇳 China', name: 'CN' },
  { code: '+91', label: '🇮🇳 India', name: 'IN' },
  { code: '+971', label: '🇦🇪 UAE', name: 'AE' },
  { code: '+27', label: '🇿🇦 South Africa', name: 'ZA' },
];

const RequestService: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [countryCode, setCountryCode] = useState('+234');
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    phone: '',
    location: '',
    issueType: 'Repair',
    description: ''
  });

  const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbypTHlMtE6aGTCwWXtFsMN5dO2HvNXxhzlcscCt3bN2A-kwZZj3gsdBa1ZQRG5ZPhzO/exec';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const submissionData = {
      ...formData,
      fullPhone: `${countryCode}${formData.phone}`
    };

    try {
      await fetch(SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', 
        headers: {
          'Content-Type': 'text/plain',
        },
        body: JSON.stringify(submissionData),
      });

      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error('Submission error:', err);
      setError('Connection error. Please check your internet or reach us via WhatsApp.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (submitted) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center bg-gray-50 px-4">
        <div className="max-w-md w-full bg-white p-10 rounded-3xl shadow-xl text-center border border-gray-100">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-4">Request Logged!</h2>
          <p className="text-gray-600 mb-8 font-medium leading-relaxed">
            Thank you, {formData.name}. Your details have been sent to Stanley's repair queue.
          </p>
          
          <div className="space-y-4">
            <a 
              href={`https://wa.me/2349062217473?text=Hi%20Stanley,%20I%20just%20submitted%20a%20service%20form%20for%20a%20${formData.issueType}.%20My%20name%20is%20${formData.name}.`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="w-full bg-green-600 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-all shadow-lg shadow-green-200"
            >
              <Send className="w-5 h-5 rotate-45" />
              Confirm via WhatsApp
            </a>
            
            <button 
              onClick={() => {
                setSubmitted(false);
                setFormData({
                  name: '',
                  company: '',
                  phone: '',
                  location: '',
                  issueType: 'Repair',
                  description: ''
                });
              }}
              className="w-full bg-gray-100 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-200 transition-all"
            >
              Submit Another Request
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-1.5 rounded-full bg-blue-100 text-blue-700 font-bold text-xs uppercase tracking-widest mb-4">
            Official Service Log
          </div>
          <h1 className="text-4xl sm:text-5xl font-black text-gray-900 mb-4 uppercase tracking-tighter">Submit Service Request</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto font-medium">
            Fill the form below to register your equipment in our system. Stanley will be notified immediately.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white p-8 sm:p-10 rounded-3xl shadow-xl border border-gray-100">
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl flex items-center gap-3 font-semibold text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  {error}
                </div>
              )}
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Contact Name *</label>
                  <input
                    required
                    disabled={loading}
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-semibold"
                    placeholder="Your Full Name"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="company" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Company / Warehouse</label>
                  <input
                    disabled={loading}
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-semibold"
                    placeholder="Where is the equipment?"
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Phone Number *</label>
                  <div className="flex gap-2">
                    <div className="relative w-32 shrink-0">
                      <select
                        disabled={loading}
                        value={countryCode}
                        onChange={(e) => setCountryCode(e.target.value)}
                        className="w-full px-3 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-bold appearance-none cursor-pointer text-sm"
                      >
                        {COUNTRY_CODES.map((item) => (
                          <option key={item.code} value={item.code}>
                            {item.label}
                          </option>
                        ))}
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                        <ChevronDown className="w-4 h-4" />
                      </div>
                    </div>
                    <input
                      required
                      disabled={loading}
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="flex-grow px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-semibold"
                      placeholder="e.g. 9062217473"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="location" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Location *</label>
                  <input
                    required
                    disabled={loading}
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-semibold"
                    placeholder="e.g. Apapa, Lagos"
                  />
                </div>
              </div>

              <div className="mb-8 space-y-2">
                <label htmlFor="issueType" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Type of Service *</label>
                <div className="relative">
                  <select
                    disabled={loading}
                    id="issueType"
                    name="issueType"
                    value={formData.issueType}
                    onChange={handleChange}
                    className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-bold appearance-none cursor-pointer"
                  >
                    <option value="Repair">General Repair</option>
                    <option value="Maintenance">Scheduled Maintenance</option>
                    <option value="Hydraulic">Hydraulic Pump Service</option>
                    <option value="Parts">Spare Parts Replacement</option>
                    <option value="Sales">Equipment Purchase Inquiry</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    <ChevronDown className="w-5 h-5" />
                  </div>
                </div>
              </div>

              <div className="mb-10 space-y-2">
                <label htmlFor="description" className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Describe the Problem *</label>
                <textarea
                  required
                  disabled={loading}
                  id="description"
                  name="description"
                  rows={4}
                  value={formData.description}
                  onChange={handleChange}
                  className="w-full px-5 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:outline-none focus:border-blue-600 focus:bg-white transition-all disabled:opacity-50 text-gray-900 font-medium resize-none"
                  placeholder="What is wrong with your pallet jack?"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="group w-full bg-blue-600 text-white py-5 rounded-2xl font-black text-xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/30 flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    Sending to Chitech Log...
                  </>
                ) : (
                  <>
                    Submit Log Entry
                    <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-2xl border border-slate-800 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-5">
                  <Info className="w-24 h-24" />
               </div>
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2 relative z-10">
                <Info className="w-5 h-5 text-blue-400" />
                Technical Note
              </h3>
              <p className="text-slate-400 leading-relaxed font-medium relative z-10">
                This form logs your data into our internal Google Sheet. We handle both local and international requests.
              </p>
            </div>

            <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-gray-100 flex flex-col items-center text-center">
              <h3 className="font-black text-gray-400 mb-6 uppercase tracking-widest text-[10px]">Instant Assistance</h3>
              <a 
                href={`tel:${BUSINESS_INFO.phone}`}
                className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mb-4 hover:bg-blue-600 hover:text-white transition-all text-blue-600"
              >
                <Send className="w-6 h-6 rotate-45" />
              </a>
              <p className="font-bold text-gray-900 mb-1">Call Stanley</p>
              <p className="text-sm text-gray-500 font-medium">{BUSINESS_INFO.phone}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestService;
