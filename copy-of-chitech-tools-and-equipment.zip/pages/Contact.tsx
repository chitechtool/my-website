
import React from 'react';
import { Phone, MessageCircle, MapPin, Clock, Facebook } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-blue-600 font-bold tracking-widest uppercase mb-4 block">Get In Touch</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 mb-6">Contact Us</h1>
          <p className="text-lg text-gray-600 max-w-xl mx-auto">
            We're located in Lagos and provide on-site services across the city and surrounding areas.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Info Side */}
          <div className="space-y-8">
            <div className="flex gap-6 p-8 rounded-2xl bg-gray-50 hover:shadow-md transition-shadow group">
              <div className="bg-blue-600 p-4 rounded-xl text-white shadow-lg group-hover:scale-110 transition-transform">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Call Us Directly</h3>
                <p className="text-gray-600 mb-4">Urgent repairs or sales inquiries? Give us a call.</p>
                <a href={`tel:${BUSINESS_INFO.phone}`} className="text-2xl font-bold text-blue-600 hover:text-blue-700">
                  {BUSINESS_INFO.phone}
                </a>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-4 p-8 rounded-2xl bg-gray-50 hover:shadow-md transition-shadow group">
                <div className="bg-green-600 p-4 rounded-xl text-white shadow-lg w-fit group-hover:scale-110 transition-transform">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">WhatsApp</h3>
                  <p className="text-gray-600 mb-4 text-sm">Fastest way to get a quote with photos.</p>
                  <a 
                    href={`https://wa.me/${BUSINESS_INFO.whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-green-700 transition-all text-sm"
                  >
                    Start Chat
                  </a>
                </div>
              </div>

              {BUSINESS_INFO.facebook && (
                <div className="flex flex-col gap-4 p-8 rounded-2xl bg-gray-50 hover:shadow-md transition-shadow group">
                  <div className="bg-blue-800 p-4 rounded-xl text-white shadow-lg w-fit group-hover:scale-110 transition-transform">
                    <Facebook className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Facebook</h3>
                    <p className="text-gray-600 mb-4 text-sm">Follow us for updates and work photos.</p>
                    <a 
                      href={BUSINESS_INFO.facebook}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-blue-800 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-900 transition-all text-sm"
                    >
                      Visit Page
                    </a>
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="p-8 rounded-2xl bg-gray-50">
                <Clock className="w-8 h-8 text-blue-600 mb-4" />
                <h4 className="font-bold text-gray-900 mb-2">Working Hours</h4>
                <p className="text-gray-600">{BUSINESS_INFO.hours}</p>
                <p className="text-gray-400 text-sm mt-2">Available for emergencies</p>
              </div>
              <div className="p-8 rounded-2xl bg-gray-50">
                <MapPin className="w-8 h-8 text-blue-600 mb-4" />
                <h4 className="font-bold text-gray-900 mb-2">Our Location</h4>
                <p className="text-gray-600">{BUSINESS_INFO.location}</p>
                <p className="text-gray-400 text-sm mt-2">Mobile service available</p>
              </div>
            </div>
          </div>

          {/* Map Side */}
          <div className="h-full min-h-[400px]">
            <div className="bg-gray-200 w-full h-full rounded-3xl overflow-hidden relative shadow-2xl">
              {/* Google Maps Placeholder */}
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                 <MapPin className="w-16 h-16 text-blue-600 mb-4 animate-bounce" />
                 <h3 className="text-2xl font-bold text-gray-800 mb-2">Lagos Service Area</h3>
                 <p className="text-gray-600 max-w-xs">
                   We serve Apapa, Ikeja, Lagos Island, Lekki, Mushin, and all major industrial hubs in Lagos State.
                 </p>
                 <div className="mt-8 bg-white/80 backdrop-blur-sm p-4 rounded-xl text-sm font-semibold border border-white">
                   Map currently showing service coverage area
                 </div>
              </div>
              {/* Overlay for "aesthetic" industrial look */}
              <div className="absolute inset-0 pointer-events-none border-[12px] border-white/10 rounded-3xl"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
