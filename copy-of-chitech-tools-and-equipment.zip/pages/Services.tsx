
import React from 'react';
import { SERVICES, BUSINESS_INFO } from '../constants';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const SERVICE_IMAGES: Record<string, string> = {
  repair: 'https://images.unsplash.com/photo-1581092162384-8987c17b4926?auto=format&fit=crop&q=80&w=1200',
  maintenance: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=1200',
  hydraulic: 'https://images.unsplash.com/photo-1516937941344-00b4e0337589?auto=format&fit=crop&q=80&w=1200',
  parts: 'https://images.unsplash.com/photo-1589793463308-658ed4224053?auto=format&fit=crop&q=80&w=1200',
  sales: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200'
};

const Services: React.FC = () => {
  return (
    <div className="bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-blue-600 font-bold tracking-widest uppercase mb-4 block">What We Offer</span>
          <h1 className="text-4xl sm:text-5xl font-black text-gray-900 mb-6 uppercase tracking-tighter">Professional Solutions</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto font-medium">
            From emergency repairs to periodic maintenance, we ensure your pallet jacks work reliably under heavy loads.
          </p>
        </div>

        <div className="space-y-16">
          {SERVICES.map((service, index) => (
            <div 
              key={service.id} 
              className={`flex flex-col lg:flex-row items-stretch bg-white rounded-[2.5rem] overflow-hidden shadow-xl border border-gray-100 ${
                index % 2 !== 0 ? 'lg:flex-row-reverse' : ''
              }`}
            >
              <div className="lg:w-1/2 relative min-h-[300px]">
                <img 
                  src={SERVICE_IMAGES[service.id] || `https://picsum.photos/seed/${service.id}/800/600`} 
                  alt={service.title} 
                  className="absolute inset-0 w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-blue-900/10 mix-blend-multiply"></div>
              </div>
              <div className="lg:w-1/2 p-8 lg:p-16 flex flex-col justify-center">
                <div className="mb-6 p-4 bg-blue-50 rounded-2xl inline-block text-blue-600 w-fit">
                  {service.icon}
                </div>
                <h3 className="text-3xl sm:text-4xl font-black mb-6 text-gray-900 uppercase tracking-tight">{service.title}</h3>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed font-medium">
                  {service.description} We specialize in {service.title.toLowerCase()} for all major brands and capacities used in Nigerian warehouses.
                </p>
                <ul className="space-y-4 mb-10">
                  <li className="flex items-center gap-3 text-gray-700 font-bold">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Quick Diagnostic Check</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-700 font-bold">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Quality Part Replacement</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-700 font-bold">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Performance Testing</span>
                  </li>
                </ul>
                <Link 
                  to="/request" 
                  className="inline-flex items-center justify-center gap-3 bg-blue-600 text-white px-8 py-5 rounded-2xl font-black text-lg hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 active:scale-95"
                >
                  Book this service
                  <ArrowRight className="w-6 h-6" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing Notice */}
        <div className="mt-20 bg-slate-950 text-white p-12 sm:p-20 rounded-[3rem] text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 p-10 opacity-5">
            <CheckCircle2 className="w-64 h-64" />
          </div>
          <h2 className="text-3xl sm:text-5xl font-black mb-6 uppercase tracking-tighter">Request a Custom Quote</h2>
          <p className="text-slate-400 mb-12 max-w-xl mx-auto text-lg font-medium leading-relaxed">
            Since every repair is unique, we provide honest estimates after initial diagnosis. For sales inquiries, contact us for latest inventory.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a 
              href={`tel:${BUSINESS_INFO.phone}`} 
              className="bg-white text-slate-950 px-10 py-5 rounded-2xl font-black text-xl hover:bg-blue-50 transition-all shadow-2xl flex items-center justify-center gap-3"
            >
              Call: {BUSINESS_INFO.phone}
            </a>
            <a 
              href={`https://wa.me/${BUSINESS_INFO.whatsapp}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-green-600 text-white px-10 py-5 rounded-2xl font-black text-xl hover:bg-green-700 transition-all shadow-2xl flex items-center justify-center gap-3"
            >
              Message WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
