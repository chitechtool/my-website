
import React from 'react';
import { BUSINESS_INFO } from '../constants';
import { User, ShieldCheck, Award, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex items-center gap-16 mb-24">
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <span className="text-blue-600 font-bold tracking-widest uppercase mb-4 block">About Us</span>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 leading-tight mb-8">
              Reliable Equipment Care by Stanley Ugbala
            </h1>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Chitech Tools and Equipment was founded with a single mission: to provide the most reliable material handling equipment servicing in Lagos. We understand that a broken pallet jack isn't just a tool problem—it's a productivity bottleneck.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Led by Stanley Ugbala, a dedicated technician with years of hands-on experience in hydraulic systems and mechanical repairs, we have built a reputation for honesty, fast response times, and superior workmanship.
            </p>
            
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h4 className="text-4xl font-bold text-blue-600 mb-2">100%</h4>
                <p className="text-gray-500 font-medium">Customer Satisfaction</p>
              </div>
              <div>
                <h4 className="text-4xl font-bold text-blue-600 mb-2">500+</h4>
                <p className="text-gray-500 font-medium">Successful Repairs</p>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-72 h-72 bg-blue-100 rounded-2xl z-0"></div>
              <img 
                src="https://images.unsplash.com/photo-1565793298595-6a879b1d9492?auto=format&fit=crop&q=80&w=1200" 
                alt="Professional yellow pallet jack in a modern warehouse" 
                className="relative z-10 rounded-2xl shadow-2xl w-full object-cover aspect-square grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-600 p-8 rounded-2xl text-white shadow-xl z-20 hidden sm:block">
                <p className="text-3xl font-bold">Lagos' #1</p>
                <p className="text-blue-100 uppercase tracking-wider text-sm">Specialist</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-3xl p-12 lg:p-20">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-gray-500 max-w-xl mx-auto">We operate on a foundation of trust and technical excellence.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <ShieldCheck className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Reliability</h3>
              <p className="text-gray-600">When we promise a fix, we deliver it. We value your time and business operations.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <Award className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Expertise</h3>
              <p className="text-gray-600">Deep knowledge of hydraulic pumps, load capacities, and structural integrity.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Integrity</h3>
              <p className="text-gray-600">Transparent pricing and honest assessments of whether to repair or replace.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
