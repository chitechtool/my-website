
import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, MessageCircle, ArrowRight, CheckCircle2, Wrench, ShieldCheck, Zap, Layers, Map } from 'lucide-react';
import { SERVICES, TRUST_BENEFITS, BUSINESS_INFO } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* AUTHENTIC INDUSTRIAL HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center bg-slate-950 overflow-hidden">
        {/* Background Image: Hardworking Technician */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&q=80&w=2076" 
            alt="Technician working on industrial hydraulic pump" 
            className="w-full h-full object-cover object-center opacity-40 mix-blend-multiply filter contrast-125"
          />
          {/* Gritty Gradient Overlays */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-blue-600/10 border border-blue-500/30 text-blue-400 font-bold tracking-widest uppercase text-xs mb-8 backdrop-blur-md">
              <Zap className="w-4 h-4 fill-current" />
              Lagos' Premier Pallet Jack Specialist
            </div>
            
            <h1 className="text-5xl sm:text-8xl font-black text-white leading-[0.95] mb-6 tracking-tighter">
              EXPERT <br />
              <span className="text-blue-500">PALLET JACK</span> <br />
              REPAIR.
            </h1>
            
            <p className="text-xl sm:text-2xl text-slate-300 mb-12 font-medium max-w-xl leading-relaxed">
              Genuine spare parts, hydraulic expertise, and rapid on-site servicing for Lagos warehouses and factories.
            </p>

            <div className="flex flex-col sm:flex-row gap-5">
              <a 
                href="https://wa.me/2349062217473?text=Hi%20I%20need%20pallet%20jack%20repair"
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-green-600 text-white px-10 py-5 rounded-xl font-black text-lg text-center hover:bg-green-700 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-green-900/40 active:scale-95"
              >
                <MessageCircle className="w-6 h-6 fill-current group-hover:scale-110 transition-transform" />
                Chat on WhatsApp
              </a>
              <Link 
                to="/request" 
                className="bg-white text-slate-900 px-10 py-5 rounded-xl font-black text-lg text-center hover:bg-blue-50 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-white/5 active:scale-95"
              >
                Request Service
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>

            {/* Coverage Stats */}
            <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-8">
              <div>
                <p className="text-blue-500 font-black text-3xl mb-1">24/7</p>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Support</p>
              </div>
              <div>
                <p className="text-blue-500 font-black text-3xl mb-1">4.9/5</p>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Rating</p>
              </div>
              <div className="hidden sm:block">
                <p className="text-blue-500 font-black text-3xl mb-1">100%</p>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Reliability</p>
              </div>
              <div className="hidden sm:block">
                <p className="text-blue-500 font-black text-3xl mb-1">LAG</p>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Mainland/Island</p>
              </div>
            </div>
          </div>
        </div>

        {/* Industrial Sidebar Info (Desktop Only) */}
        <div className="hidden xl:block absolute right-12 top-1/2 -translate-y-1/2 z-20">
          <div className="space-y-4">
            <div className="bg-slate-900/40 backdrop-blur-xl p-4 rounded-2xl border border-white/10 text-white flex items-center gap-4">
              <div className="p-3 bg-blue-600 rounded-xl shadow-lg shadow-blue-600/30">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Tools Ready</p>
                <p className="text-sm font-bold">Stanley Ugbala</p>
              </div>
            </div>
            <div className="bg-slate-900/40 backdrop-blur-xl p-4 rounded-2xl border border-white/10 text-white flex items-center gap-4">
              <div className="p-3 bg-slate-800 rounded-xl">
                <Map className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Active In</p>
                <p className="text-sm font-bold">Apapa/Ikeja</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BENEFITS SECTION */}
      <section className="bg-white py-20 relative -mt-10 rounded-t-[3rem] z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {TRUST_BENEFITS.map((benefit, index) => (
              <div key={index} className="group flex flex-col p-8 rounded-3xl bg-slate-50 border-2 border-transparent hover:border-blue-600/20 hover:bg-white hover:shadow-2xl transition-all duration-500">
                <div className="bg-blue-600 text-white p-4 rounded-2xl w-fit mb-6 shadow-lg shadow-blue-600/20 group-hover:scale-110 transition-transform">
                  {benefit.icon}
                </div>
                <h3 className="font-black text-xl text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600 leading-relaxed font-medium">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES GRID */}
      <section className="bg-slate-50 py-24 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div className="max-w-2xl">
              <div className="w-12 h-1.5 bg-blue-600 mb-6"></div>
              <h2 className="text-4xl sm:text-6xl font-black text-gray-900 mb-4 tracking-tight uppercase">Industrial <br />Support.</h2>
              <p className="text-lg text-gray-600 font-medium">
                Engineered for Lagos’ toughest environments. We provide comprehensive repair and maintenance for your material handling fleet.
              </p>
            </div>
            <Link to="/services" className="inline-flex items-center gap-2 font-black text-blue-600 hover:text-blue-700 transition-colors uppercase tracking-widest text-sm">
              View All Services <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {SERVICES.map((service) => (
              <div key={service.id} className="bg-white p-10 rounded-3xl shadow-sm border border-slate-200 hover:border-blue-600 transition-all duration-300 flex flex-col h-full relative group">
                <div className="mb-8 p-4 bg-slate-50 rounded-2xl inline-block text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-black mb-4 text-gray-900 leading-tight uppercase">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-8 flex-grow font-medium">
                  {service.description}
                </p>
                <Link 
                  to="/services" 
                  className="w-full py-4 rounded-xl border-2 border-slate-100 text-center font-black text-slate-900 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all uppercase text-xs tracking-widest"
                >
                  View Details
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* RECENT WORK GALLERY */}
      <section className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter sm:text-5xl">Recent Repair Jobs</h2>
            <p className="text-gray-500 mt-4 font-medium">Real photos from on-site repairs across Lagos industrial hubs.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <img src="https://images.unsplash.com/photo-1581092162384-8987c17b4926?auto=format&fit=crop&q=80&w=800" className="rounded-2xl h-48 sm:h-72 w-full object-cover grayscale hover:grayscale-0 transition-all duration-500 border border-slate-200" alt="Repair 1" />
            <img src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=800" className="rounded-2xl h-48 sm:h-72 w-full object-cover grayscale hover:grayscale-0 transition-all duration-500 border border-slate-200" alt="Repair 2" />
            <img src="https://images.unsplash.com/photo-1530124566582-aa61dd3c90ba?auto=format&fit=crop&q=80&w=800" className="rounded-2xl h-48 sm:h-72 w-full object-cover grayscale hover:grayscale-0 transition-all duration-500 border border-slate-200" alt="Repair 3" />
            <img src="https://images.unsplash.com/photo-1454165833767-027fffd16082?auto=format&fit=crop&q=80&w=800" className="rounded-2xl h-48 sm:h-72 w-full object-cover grayscale hover:grayscale-0 transition-all duration-500 border border-slate-200" alt="Repair 4" />
          </div>
        </div>
      </section>

      {/* URGENT CTA SECTION */}
      <section className="bg-slate-950 py-24 relative overflow-hidden">
        <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-blue-600 p-10 sm:p-20 rounded-[3rem] border border-blue-500 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
               <Layers className="w-48 h-48 text-white" />
            </div>
            <div className="max-w-3xl">
              <h2 className="text-4xl sm:text-7xl font-black text-white mb-8 leading-tight tracking-tighter uppercase">Equipment Down? <br />We're On Our Way.</h2>
              <p className="text-xl text-blue-100 mb-12 font-medium leading-relaxed">
                Minimize your downtime. Stanley Ugbala and the Chitech team provide rapid response repairs anywhere in Lagos.
              </p>
              <div className="flex flex-col sm:flex-row gap-6">
                 <a 
                   href={`tel:${BUSINESS_INFO.phone}`} 
                   className="bg-white text-blue-700 px-12 py-5 rounded-2xl font-black text-xl flex items-center justify-center gap-3 hover:bg-blue-50 transition-all shadow-2xl"
                 >
                   <Phone className="w-6 h-6" />
                   {BUSINESS_INFO.phone}
                 </a>
                 <Link 
                   to="/request" 
                   className="bg-slate-900 text-white px-12 py-5 rounded-2xl font-black text-xl flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-2xl"
                 >
                   Book Service
                 </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
