
// Fix: Added React import to resolve 'Cannot find namespace React' error when using React.ReactNode
import React from 'react';

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface BusinessInfo {
  name: string;
  owner: string;
  location: string;
  phone: string;
  whatsapp: string;
  facebook?: string;
  email: string;
  hours: string;
}

export interface FormData {
  name: string;
  company: string;
  phone: string;
  location: string;
  issueType: string;
  description: string;
}
